package com.unione.cloud.demo.model;
import org.beetl.sql.annotation.entity.Table;
import org.beetl.sql.mapper.annotation.SqlResource;

import com.unione.cloud.beetsql.annotation.KeyWords;
import com.unione.cloud.core.model.Pojo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @标题 	DemoTest Entity
 * @描述	demo：test
 * @作者	Unione Cloud CodeGen
 * @日期	2025-10-21 12:14:39
 * @版本	1.0.0
 **/
@Data
@Builder
@SqlResource("demo.DemoTest")
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@Table(name="demo_test")
public class DemoTest extends Pojo {
	/**
	* 标题
	*/
	@KeyWords
	@Schema(title="标题",description="长度为：50")
	private String title;
	/**
	* URL
	*/
	@Schema(title="URL",description="长度为：250")
	private String url;
	/**
	* 描述
	*/
	@KeyWords
	@Schema(title="描述",description="长度为：500")
	private String descs;

}
